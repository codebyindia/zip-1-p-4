import json
import os
import time
import boto3
from botocore.config import Config

def disable_failback(event, context):

    primary_nlb_tag = os.getenv("PRIMARY_NLB")
    primary_tg_tag = os.getenv("PRIMARY_TG")
    secondary_tg_tag = os.getenv("SECONDARY_TG")
    unhealthy_tg_tag = os.getenv("UNHEALTHY_TG")
    region = list(os.getenv("REGION").split(","))
    healthyValues = list(os.getenv("HEALTHY_VALUES").split(","))

    def get_arn_by_tag(name, region):
        my_config = Config(region_name = region)
        tag = boto3.client('resourcegroupstaggingapi', config=my_config)
        return tag.get_resources(
            TagFilters=[{'Key': 'Name','Values': [name]}]
            )['ResourceTagMappingList'][0]['ResourceARN']

    def is_healthy(targetgrouparn, region):
        my_config = Config(region_name = region)
        client = boto3.client('elbv2', config=my_config)
        target_health_data = client.describe_target_health(TargetGroupArn = targetgrouparn)['TargetHealthDescriptions']
        return any([item['TargetHealth']['State'] in healthyValues for item in target_health_data])

    client = boto3.client('elbv2')
    load_balancer_arn = get_arn_by_tag(primary_nlb_tag, region[0])

    while (is_healthy(get_arn_by_tag(primary_tg_tag, region[0]), region[0])):
        time.sleep(1)

    listener_arn = client.describe_listeners(
    LoadBalancerArn = load_balancer_arn
    )['Listeners'][0]['ListenerArn']

    if (is_healthy(get_arn_by_tag(secondary_tg_tag, region[1]), region[1])):
        client.delete_listener(ListenerArn = listener_arn)

        time.sleep(1)
        unhealthy_tg = get_arn_by_tag(unhealthy_tg_tag, region[0])
        client.create_listener(
            LoadBalancerArn = load_balancer_arn,
            Protocol = 'TCP',
            Port = 9096,
            DefaultActions = [{'Type' : 'forward', 'TargetGroupArn' : unhealthy_tg}]
        )

    return {
        'statusCode': 200,
        'body': json.dumps('The target group of the NLB has been changed')
    }
