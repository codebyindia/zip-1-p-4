package com.msk;

import com.google.inject.Inject;
import com.google.inject.name.Named;

import org.jsmart.zerocode.core.engine.preprocessor.ScenarioExecutionState;
import org.jsmart.zerocode.core.kafka.client.BasicKafkaClient;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Customized Kafka client to support Cluster Switching.
 */
public class MSKDRKafkaClient extends BasicKafkaClient {
    private Logger LOGGER = LoggerFactory.getLogger(MSKDRKafkaClient.class);
    private static final String CONSUMER_LOCAL_CONFIG = "consumerLocalConfigs";

    @Inject
    @Named("kafka.bootstrap.secondary.servers")
    /*Reference for the Secondary MSK Cluster. */
    private String secondaryServer;

    @Inject
    @Named("kafka.mirrored.topic.prefix")
    /*Topic prefix when the messages are mirrored to Secondary Cluster. */
    private String topicPrefix;

    @Override
    public String execute(String brokers, String topicName, String operation, String requestJson,
     final ScenarioExecutionState scenarioExecutionState) {

        if (operation.equals("consume_secondary")
         || (operation.equals("consume") && brokers != secondaryServer)) {
            JSONObject jsonObject = new JSONObject(requestJson);
            if(jsonObject.getJSONObject(CONSUMER_LOCAL_CONFIG).has("seek")) {
                String seek = jsonObject.getJSONObject(CONSUMER_LOCAL_CONFIG).getString("seek");
                jsonObject.getJSONObject(CONSUMER_LOCAL_CONFIG).put("seek", seek.replace(topicName, topicPrefix+topicName));
                requestJson = jsonObject.toString();
            }
            topicName = topicPrefix + topicName;
            LOGGER.info("Setting up the Secondary Cluster for Consume Operation against topic: " + topicName);
            brokers = secondaryServer;
        }

        operation = operation.split("_")[0];

        return super.execute(brokers, topicName, operation, requestJson, scenarioExecutionState);
    }
}
