# terraform

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 3.74 |
| <a name="requirement_helm"></a> [helm](#requirement\_helm) | 2.5.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 3.74 |
| <a name="provider_aws.origin"></a> [aws.origin](#provider\_aws.origin) | ~> 3.74 |
| <a name="provider_helm"></a> [helm](#provider\_helm) | 2.5.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [helm_release.mm2_deployment](https://registry.terraform.io/providers/hashicorp/helm/2.5.0/docs/resources/release) | resource |
| [random_id.helm_release_check](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/id) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_eks_cluster.eks](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/eks_cluster) | data source |
| [aws_eks_cluster_auth.eks](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/eks_cluster_auth) | data source |
| [aws_msk_cluster.destination_msk](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/msk_cluster) | data source |
| [aws_msk_cluster.source_msk](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/msk_cluster) | data source |
| [aws_secretsmanager_secret.destination-msk-secret](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/secretsmanager_secret) | data source |
| [aws_secretsmanager_secret.source-msk-secret](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/secretsmanager_secret) | data source |
| [aws_secretsmanager_secret_version.destination-msk-secret-version](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/secretsmanager_secret_version) | data source |
| [aws_secretsmanager_secret_version.source-msk-secret-version](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/secretsmanager_secret_version) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_account_id"></a> [account\_id](#input\_account\_id) | The ID of the AWS account where Terraform will be run. | `string` | n/a | yes |
| <a name="input_artifactory_path"></a> [artifactory\_path](#input\_artifactory\_path) | n/a | `string` | `"artifactory.blackstone.com/docker-local/devops/thoughtworks"` | no |
| <a name="input_destination-msk-secret-name"></a> [destination-msk-secret-name](#input\_destination-msk-secret-name) | n/a | `string` | n/a | yes |
| <a name="input_destination_msk_cluster_name"></a> [destination\_msk\_cluster\_name](#input\_destination\_msk\_cluster\_name) | The name of destination/DR MSK cluster | `string` | n/a | yes |
| <a name="input_eks_cluster_name"></a> [eks\_cluster\_name](#input\_eks\_cluster\_name) | # EKS | `string` | n/a | yes |
| <a name="input_mm2_deployment"></a> [mm2\_deployment](#input\_mm2\_deployment) | The mm2 deployments to be created on EKS cluster | <pre>map(object({<br>    mm2_topic_name = string<br>  }))</pre> | n/a | yes |
| <a name="input_mm2_helm_artifactory_path"></a> [mm2\_helm\_artifactory\_path](#input\_mm2\_helm\_artifactory\_path) | n/a | `string` | `"https://artifactory.blackstone.com/artifactory/bxi-devops-helm-local"` | no |
| <a name="input_mm2_helm_chart_name"></a> [mm2\_helm\_chart\_name](#input\_mm2\_helm\_chart\_name) | n/a | `string` | `"mirrormaker2"` | no |
| <a name="input_mm2_helm_chart_version"></a> [mm2\_helm\_chart\_version](#input\_mm2\_helm\_chart\_version) | n/a | `string` | n/a | yes |
| <a name="input_mm2_namespace"></a> [mm2\_namespace](#input\_mm2\_namespace) | n/a | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | The region where Terraform will deploy infrastructure. | `string` | n/a | yes |
| <a name="input_source-msk-secret-name"></a> [source-msk-secret-name](#input\_source-msk-secret-name) | n/a | `string` | n/a | yes |
| <a name="input_source_image_name"></a> [source\_image\_name](#input\_source\_image\_name) | n/a | `string` | `"tw-mirrormaker2"` | no |
| <a name="input_source_image_tag"></a> [source\_image\_tag](#input\_source\_image\_tag) | n/a | `string` | `"latest"` | no |
| <a name="input_source_msk_cluster_name"></a> [source\_msk\_cluster\_name](#input\_source\_msk\_cluster\_name) | The name of source MSK cluster | `string` | n/a | yes |
| <a name="input_splunk_annotations_env"></a> [splunk\_annotations\_env](#input\_splunk\_annotations\_env) | n/a | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
