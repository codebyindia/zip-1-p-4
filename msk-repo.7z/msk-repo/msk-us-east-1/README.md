# terraform

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 3.74 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 3.74 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_bx_msk_cluster"></a> [bx\_msk\_cluster](#module\_bx\_msk\_cluster) | ./modules/terraform-aws-bx_msk_cluster | n/a |
| <a name="module_sasl_scram_secret"></a> [sasl\_scram\_secret](#module\_sasl\_scram\_secret) | localterraform.com/blackstone/bx_msk_sasl_scram_secret/aws | 0.3.3 |
| <a name="module_source_cidr_blocks"></a> [source\_cidr\_blocks](#module\_source\_cidr\_blocks) | localterraform.com/blackstone/bx_standard_ingress_cidrs/aws | 0.6.0 |

## Resources

| Name | Type |
|------|------|
| [aws_kms_grant.msk_ops_kms_grant](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/kms_grant) | resource |
| [aws_msk_configuration.config](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/msk_configuration) | resource |
| [aws_msk_configuration.default_config](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/msk_configuration) | resource |
| [aws_msk_scram_secret_association.secret_association](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/msk_scram_secret_association) | resource |
| [aws_security_group.msk_security_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_vpc.selected](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/vpc) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_account_id"></a> [account\_id](#input\_account\_id) | The ID of the AWS account where Terraform will be run. | `string` | n/a | yes |
| <a name="input_bx_eks_admin_role_arn"></a> [bx\_eks\_admin\_role\_arn](#input\_bx\_eks\_admin\_role\_arn) | The ARN for the operator role that needs access to the KMS key to retrieve secrets | `string` | n/a | yes |
| <a name="input_default_kafka_versions"></a> [default\_kafka\_versions](#input\_default\_kafka\_versions) | The default supported kafka versions for the default configuration | `list(string)` | <pre>[<br>  "2.2.1",<br>  "2.3.1",<br>  "2.4.1.1",<br>  "2.5.1",<br>  "2.6.0"<br>]</pre> | no |
| <a name="input_is_prod"></a> [is\_prod](#input\_is\_prod) | True if it's prod environment, false if it's nonprod | `bool` | `false` | no |
| <a name="input_kafka_instances"></a> [kafka\_instances](#input\_kafka\_instances) | The environment specific instances since there's more than one per workspace | <pre>map(object({<br>    broker_instance_type              = string,<br>    kafka_version                     = string,<br>    super_users                       = string,<br>    num_kafka_broker_nodes            = number,<br>    cidr_blocks                       = list(string)<br>    include_onprem_cidrs              = bool<br>    include_aws_cidrs                 = bool<br>    include_shared_services_aws_cidrs = bool<br>  }))</pre> | n/a | yes |
| <a name="input_kafka_secret_associations"></a> [kafka\_secret\_associations](#input\_kafka\_secret\_associations) | A collection of the MSK secret associations. | <pre>map(object({<br>    cluster                   = string,<br>    username                  = string,<br>    secret_name               = string,<br>    cross_account_access_arns = list(string)<br>  }))</pre> | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | The region where Terraform will deploy infrastructure. | `string` | n/a | yes |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | The ID of the VPC where Terraform will deploy infrastructure. | `string` | n/a | yes |
| <a name="input_workspace"></a> [workspace](#input\_workspace) | The environmental suffix to append to the workspace name in Terraform Enterprise. | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
