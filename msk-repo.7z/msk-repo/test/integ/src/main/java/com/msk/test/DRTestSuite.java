package com.msk.test;

import com.msk.test.basic.KafkaProduceTest;

import org.junit.internal.TextListener;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runners.model.InitializationError;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import junit.extensions.ActiveTestSuite;
import junit.framework.JUnit4TestAdapter;
import junit.framework.TestSuite;

public class DRTestSuite {
    private static final Logger LOGGER = LoggerFactory.getLogger(DRTestSuite.class);
    public static void main(String[] args) throws InitializationError {

        TestSuite mySuite = new ActiveTestSuite();

        JUnitCore junit = new JUnitCore();

        junit.addListener(new TextListener(System.out));

        mySuite.addTest(new JUnit4TestAdapter(
            KafkaProduceTest.class));

        Result testResult = junit.run(mySuite);

        LOGGER.info("Total Run: %d; Failed: %d, Ignored: %d", testResult.getRunCount(),
          testResult.getFailureCount(), testResult.getIgnoreCount());

        System.exit(testResult.getFailureCount());
    }
}
