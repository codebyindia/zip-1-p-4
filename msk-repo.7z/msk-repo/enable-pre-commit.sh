#! /usr/bin/env bash
# check and enable missing pre-commit hooks in your current repo
# TODO: shorten with functions
git -C $(pwd) rev-parse
exit_code=$(echo $?)
if [ "$exit_code" -eq 0 ] ; then
  cd $(git rev-parse --show-toplevel)
  echo "installing/checking pre-commit hooks in git repo" :  $(pwd)
  if ! [ -f .pre-commit-config.yaml ]; then
    echo "pre-commit configurations file does not exist"
    exit 1
  fi
  if ! [ -f .git/hooks/pre-commit ]; then
    echo "hook stage 'pre-commit' not found ... installing/enabling"
    pre-commit install
  else
    echo "pre-commit stage already enabled"
  fi
  # finally parse all the hook stages in the config file that needs to be enabled
  command -v yq >> /dev/null
  if ! [ $? -eq 0 ]; then
    echo "installing yq"
    brew install yq
  fi
  for i in $(yq e '.repos.[].hooks.[].stages.[]' .pre-commit-config.yaml | sort -u); do
    # commit stage is implicitly installed
    if  [ $i != 'commit' ] ; then
      if ! [ -f .git/hooks/$i ] ; then
        echo "hook stage '$i' not found ... installing/enabling"
        pre-commit install --hook-type $i
      else
        echo "$i stage already enabled"
      fi
    fi
  done
else
  echo $(pwd) : is not a git repository
  exit 1
fi
