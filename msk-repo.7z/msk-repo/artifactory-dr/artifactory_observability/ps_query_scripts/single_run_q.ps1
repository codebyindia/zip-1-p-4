$folderName = ".\sprint_8\authored\downEqTo0"

$json_query = @"
items.find(
{
    "stat.downloads":{"`$eq":null}
},
{
    "created_by":{"`$nmatch":"*anonymous*"}
},
{
    "created":{"`$last" : "24mo"}
}
).include("name","path","size", "created_by")
"@

$json_query | Out-File -Encoding "Ascii" -FilePath ".\common_query.json"
# $raw_query = ConvertFrom-Json $json_query
jf rt curl -X POST /api/search/aql -T common_query.json | Out-File -FilePath .\${folderName}\created_last_24mo.json
