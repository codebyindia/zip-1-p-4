$folderName = ".\sprint_8\authored\downEqTo0\"


$before = '6mo'
$last = '12mo'

$json_query = @"
items.find(
{
    "stat.downloads":{"`$eq":null}
},
{
    "created_by":{"`$nmatch":"*anonymous*"}
},
{
    "`$and":
    [
        {"created":{"`$before" : "$before"}},
        {"created":{"`$last" : "$last"}}
    ]
}
).include("name","path","size","created_by")
"@

$json_query | Out-File -Encoding "Ascii" -FilePath ".\common_query.json"
# $raw_query = ConvertFrom-Json $json_query
jf rt curl -X POST /api/search/aql -T common_query.json | Out-File -FilePath .\${folderName}\created_between_${before}_And_${last}_ago.json
