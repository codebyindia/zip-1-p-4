#! /usr/bin/env bash
COMMIT_FILE=$1
message_line=$(head -n 1 $COMMIT_FILE)
CARD_REGEX="^TW-[0-9]{1,}\b\s[|]\s.*\s[|]\s.*$"
AUTHOR_REGEX="^.*[|]\s([A-Z]{1}[a-z]{2,}[\/]{0,}){1,}\b\s[|].*$"
MESSAGE_REGEX="^.*[|].*[|]\s(.{20,50}){1}$"

match_story_card() {
	if ! echo "$message_line" | grep -E "$CARD_REGEX" ; then
		echo "The commit message does not mention story number correctly"
		exit 1
	fi
}

match_author_regex() {
  if ! echo "$message_line" | grep -E "$AUTHOR_REGEX" ; then
		echo "The commit message does not mention story authors correctly"
		exit 1
	fi
}

match_message_details() {
  if ! echo "$message_line" | grep -E "$MESSAGE_REGEX" ; then
		echo "The commit message should be between 20 to 50 characters long"
		exit 1
	fi
}

match_story_card
match_author_regex
match_message_details
