## Build and push a new image
1. Create a directory inside the mask-repo
2. Create a makefile which includes `artifactory-login`, `build` and `publish` targets.
3. If you need to set any environment variables, add them to the `config.env` file.
4. To run the Jenkins Pipeline for your directory, pass `makefile_dir` as parameter during runtime.
5. For security scanning `grype-scan` and `dockle-scan` makefile targets are used.
