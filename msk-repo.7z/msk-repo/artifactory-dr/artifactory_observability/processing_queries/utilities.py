import os, json

###
### Utilities
###
def get_printable_size(byte_size):
    """
    1 byte = 1 octet = 8 bits
    1 kB = 1 kilobyte = 1000 bytes = 10^3 bytes
    1 KiB = 1 kibibyte = 1024 bytes = 2^10 bytes
    1 KB = 1 kibibyte OR kilobyte ~= 1024 bytes ~= 2^10 bytes (it usually means 1024 bytes but sometimes it's 1000... ask the sysadmin ;) )
    1 kb = 1 kilobits = 1000 bits (this notation should not be used, as it is very confusing)
    1 ko = 1 kilooctet = 1000 octets = 1000 bytes = 1 kB
    """
    BASE_SIZE = 1024.00
    MEASURE = ["B", "KB", "MB", "GB", "TB", "PB"]

    def _fix_size(size, size_index):
        if not size:
            return "0"
        elif size_index == 0:
            return str(size)
        else:
            return "{:.3f}".format(size)

    current_size = byte_size
    size_index = 0

    while current_size >= BASE_SIZE and len(MEASURE) != size_index:
        current_size = current_size / BASE_SIZE
        size_index = size_index + 1

    size = _fix_size(current_size, size_index)
    measure = MEASURE[size_index]
    return size + measure


def readable_size(folders_dict):
    """
    Make the size value in dicts readble.
    """
    for key, value in folders_dict.items():
        if value is not None:
            folders_dict[key] = get_printable_size(value)

    return folders_dict


def select_files(query_files, skip_files):
    # print(skip_files)
    for skipper in skip_files:
        for file in query_files:
            if skipper in file:
                query_files.remove(file)
    # print(query_files)
    return query_files


def turn_None_into_0(a_dict):
    for key in a_dict.keys():
        if a_dict[key] is None:
            a_dict[key] = 0
    return a_dict


def order_dict_by_key(a_dict):
    """
    arguments:
    ________________
    a_dict: dict -- dictionary to order;

    Keys are converted into integers before.
    Order the elements of the dictionary by keys.

    return:
    ________________
    sorted: dict -- ordered input dictionary;
    """
    temp_dict = {}
    a_dict = {int(k): v for k, v in a_dict.items()}  # dict comprehension
    sorted_items = sorted(a_dict.items(), reverse=True)
    for key, value in sorted_items:
        temp_dict.setdefault(key, value)

    return temp_dict


def order_dict_by_value(a_dict):
    """
    arguments:
    ________________
    a_dict: dict -- dictionary to order;

    Expects that values are integers!
    Order the elements of the dictionary by values.

    return:
    ________________
    sorted: dict -- ordered input dictionary;
    """
    sorted_items = {
        k: v for k, v in sorted(a_dict.items(), key=lambda item: item[1], reverse=True)
    }  # dict comprehension

    return sorted_items


def write_result_to_file(folder_path, results_filename, results_dict):
    """
    arguments:
    ________________
    folder_path: str -- path to a folder;
    results_filename: str -- the name of the file;
    results_dict: dict -- a dict to write in json format;

    Writes a dictionary to a json file.

    returns:
    ________________
    Nothing
    """
    save_path = folder_path + "/results/" + str(results_filename) + ".json"
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    with open(save_path, "w") as fp:
        json.dump(results_dict, fp)


def build_folder_dict(unique_folders_paths):
    """
    Builds a dict for all the unique paths.
    """
    temp_dict = {}
    for folder in unique_folders_paths:
        temp_dict[folder] = None

    return temp_dict


def create_root_folder(folder_list):
    """
    Some items are placed in the root folder.
    This function checks for this case and adds a correction.
    """
    if len(folder_list) == 1:
        folder_path = "ROOT-REPO:{}".format(folder_list[0])
    else:
        folder_path = "{}/{}".format(folder_list[0], folder_list[1])
    return folder_path


def get_root(folder_list):
    return "{}".format(folder_list[0])
