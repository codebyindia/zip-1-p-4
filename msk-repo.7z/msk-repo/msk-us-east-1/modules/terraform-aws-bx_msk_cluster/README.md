# Module: bx_msk_cluster

This module provisions an AWS Managed Streaming Kafka (MSK) cluster to a given VPC.
It requires the following parameters for the default configuration:
1. VPC ID
    - The target VPC where the cluster will be provisioned.

2. Client Authentication Type
    - This represents the MSK authentication type.  SASL/SCRAM and TLS are supported.

3. Environment
    - The environment the cluster is provisioned in.  This is applied to the resource tags.

4. Owner
    - The owner of the cluster.  This is applied to the resource tags.

5. Cluster Name
    - The name assigned to the provisioned cluster.

6. Private Certificate Authority ARN
    - The ARN to the AWS private certificate authority
    used for client authentication over TLS.

The default configuration is setup with a security group that allows access to the MSK broker over TLS on port 9094
and ZooKeeper on port 2181 to all IPs within the same VPC.  If you require different security group rules, you can
pass the security group IDs you wish to use as seen in the Custom Security Group example below.

## Example Usage (Basic)
```hcl
module "my-msk-cluster" {
  source  = "localterraform.com/blackstone/bx_msk_cluster/aws"
  version = "0.0.0"

  vpc_id                     = "vpc-1235678890"
  cluster_name               = "my-unique-cluster-name"
  ca_arn                     = "arn:aws:acm-pca:us-east-1:0123456789:certificate-authority/some-guid-like-string"
  client_authentication_type = "TLS"
  environment                = "dev"
  owner                      = "Platform Engineering"
}
```

## Example Usage (Custom Security Groups)
```hcl
module "my-msk-cluster" {
  source  = "localterraform.com/blackstone/bx_msk_cluster/aws"
  version = "0.0.0"

  vpc_id                     = "vpc-1235678890"
  cluster_name               = "my-unique-cluster-name"
  ca_arn                     = "arn:aws:acm-pca:us-east-1:0123456789:certificate-authority/some-guid-like-string"
  client_authentication_type = "TLS"
  environment                = "dev"
  owner                      = "Platform Engineering"
  custom_security_group_ids = ["sgid-1","sgid-2"]
}
```

## Example Usage (SASL/SCRAM)
```hcl
module "my-msk-cluser" {
    source  = "localterraform.com/blackstone/bx_msk_cluster/aws"
  version = "0.0.0"

  vpc_id                     = "vpc-1235678890"
  cluster_name               = "my-unique-cluster-name"
  client_authentication_type = "SASL/SCRAM"
  msk_sasl_secret_name       = "secret_name"
  environment                = "dev"
  owner                      = "Platform Engineering"
}

```

## Kafka Configuration
By default, MSK is configured using the default configuration provided by Amazon which can
be found at: https://docs.aws.amazon.com/msk/latest/developerguide/msk-default-configuration.html.
However, you may provision a cluster with a custom configuration via the `configuration` variable.
This is typically done using the heredoc format like the example below:

```bash
configuration = <<PROPERTIES
auto.create.topics.enable = false
compression.type = producer
default.replication.factor = 3
delete.topic.enable = true
group.initial.rebalance.delay.ms = 3000
group.max.session.timeout.ms = 1800000
group.min.session.timeout.ms = 6000
leader.imbalance.per.broker.percentage = 10
log.cleaner.delete.retention.ms = 86400000
log.cleaner.min.cleanable.ratio = 0.5
log.cleanup.policy = delete
log.flush.interval.messages = 9223372036854775807
log.retention.bytes = -1
log.retention.hours = 168
log.roll.ms = 168
log.segment.bytes = 1073741824
max.incremental.fetch.session.cache.slots = 1000
message.max.bytes = 1048588
log.message.timestamp.difference.max.ms = 9223372036854775807
log.message.timestamp.type = CreateTime
min.insync.replicas = 2
num.io.threads = 8
num.network.threads = 5
num.recovery.threads.per.data.dir = 1
num.replica.fetchers = 2
num.partitions = 1
offsets.retention.minutes = 10080
offsets.topic.replication.factor = 3
replica.fetch.max.bytes = 1048576
replica.fetch.response.max.bytes = 10485760
replica.lag.time.max.ms = 30000
socket.receive.buffer.bytes = 102400
socket.request.max.bytes = 104857600
socket.send.buffer.bytes = 102400
replica.socket.receive.buffer.bytes = 65536
transactional.id.expiration.ms = 604800000
transaction.max.timeout.ms = 900000
transaction.state.log.min.isr = 2
transaction.state.log.replication.factor = 3
unclean.leader.election.enable = true
zookeeper.session.timeout.ms = 18000
PROPERTIES
```

## Details
This module relies on having an AWS Private Certificate Authority ARN to issue and sign client certs for TLS authentication.  Currently, there is no automated way to sign and issue certs for client authentication and is currently done using the instructions that are found on AWS' developer guide at:
https://docs.aws.amazon.com/msk/latest/developerguide/msk-authentication.html
