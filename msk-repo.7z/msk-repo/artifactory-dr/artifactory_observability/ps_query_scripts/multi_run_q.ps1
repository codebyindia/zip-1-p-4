$moList = "24mo","12mo","6mo","1mo"

$folderName = ".\sprint_8\authored\downEqTo1"

foreach ($mo in $moList)
{
$json_query = @"
items.find(
{
    "stat.downloads":{"`$eq":1}
},
{
    "created_by":{"`$nmatch":"*anonymous*"}
},
{
    "stat.downloaded":{"`$before" : "$mo"}
}
).include("name","path","size", "created_by", "stat.downloaded_by", "stat.downloaded")
"@

$json_query | Out-File -Encoding "Ascii" -FilePath ".\common_query.json"
# $raw_query = ConvertFrom-Json $json_query
jf rt curl -X POST /api/search/aql -T common_query.json | Out-File -FilePath .\$folderName\before$mo-months.json
}
Copy-Item ".\common_query.json" -Destination ".\$folderName"
