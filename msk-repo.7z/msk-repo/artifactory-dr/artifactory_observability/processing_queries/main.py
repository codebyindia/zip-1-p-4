import json
import os
import re
from path_and_size_pipeline import path_and_size_pipeline
from author_and_items_pipeline import author_and_items_pipeline
from rich import print


def main():
    folder_path = "../sprint_8/authored/downEqTo0/"
    skip_files = [
        "common_query.json",
        "results",
        "created_before_24mo_ago.json",
        "created_last_24mo.json",
    ]

    path_and_size_pipeline(folder_path, skip_files)
    author_and_items_pipeline(folder_path, skip_files)


if __name__ == "__main__":
    main()
