#! /usr/bin/env python3

import sys

with open(sys.argv[1], "r") as commit_messge_file:
    commit_array = commit_messge_file.read().splitlines()

    if len(commit_array) < 3:
        print(f"Commit message is missing details")
        exit(1)
    elif len(commit_array[1]) > 0:
        print(f"Commit message second line is not blank")
        exit(1)
    elif len([each for each in commit_array[1:] if len(each) > 72 and each.split()[0] not in ["Co-authored-by:", "#"]]) > 0:
        print(f"Some lines in the commit message extend to more than 72 characters")
        exit(1)
    elif len(' '.join([each for each in commit_array[1:] if each != '' and each.split()[0] not in ["Co-authored-by:", "#"]]).split()) < 5:
        print("Commit message body is missing details")
        exit(1)
