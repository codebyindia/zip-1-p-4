import json
import os
import re
from utilities import (
    get_printable_size,
    select_files,
    order_dict_by_key,
    turn_None_into_0,
)
from utilities import (
    write_result_to_file,
    create_root_folder,
    build_folder_dict,
    readable_size,
    order_dict_by_value,
)
from rich import print


def get_unique_(key, folder_path, skip_files):
    """
    arguments:
    ________________
    key: str -- the key to look for in the resulted dict
    folder_path: str -- path to the folder where the query results are;
    skip_files: list -- a list of files to be skipped from processing;

    returns:
    ________________
    unique_folders_paths: list -- all the unique folders in the query;
    """
    query_files = os.listdir(folder_path)
    unique_list = []
    selected_query_files = select_files(query_files, skip_files)

    for file in selected_query_files:
        file_path = folder_path + file
        with open(file_path, "rb") as opened_file:
            data = opened_file.read()
            json_data = json.loads(data)
            for result_dict in json_data["results"]:
                value = result_dict[key]
                if value not in unique_list:
                    unique_list.append(value)

    return unique_list


def author_and_items_pipeline(folder_path, skip_files):
    unique_authors = get_unique_("created_by", folder_path, skip_files)
    write_result_to_file(folder_path, "unique_authors", unique_authors)
    unique_items = get_unique_("name", folder_path, skip_files)
    write_result_to_file(folder_path, "unique_items", unique_items)
