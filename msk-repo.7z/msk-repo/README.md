## Clone this repository
1. Generate ssh key with `ssh-keygen`
2. Upload public key with `.pub` extention here in SSH keys [Link](https://gitlab.blackstone.com/-/profile/keys)
3. Clone repository with ssh option `git clone --config core.sshCommand="ssh -i <your_private_key_path>" git@gitlab.blackstone.com:devops/msk-repo.git`
4. Set local config `git config --local core.sshCommand "ssh -i <your_private_key_path>"`

## Pre-Commit Hygine
- Pre-commit hooks are already enabled in the repository
- A developer has to install `pre-commit`, `talisman`, `tfsec` and `git-mob`
- Developer has to ensure, before a commit all the checks of pre-commit has to pass
- Developer can force run pre-commit hook on every file of repository without a commit `pre-commit run -a`

### pre-commit setup convenience scripts
To ease developer's life the setup of pre-commit utilities has been automated.
- Execute `sh setup-precommit.sh` to setup pre-commit tools in your laptop
- Enable all the commit hooks stages in your repo by running `sh enable-pre-commit.sh`

### Effective mob / pair programming
- `git-mob` has a `co-author` pre-commit hook that  adds `co-authored-by` sections in the commit message
- to enable git-mob, install it using `npm install -g git-mob`
- next step is to enable the hook in the repository `pre-commit install --hook-type prepare-commit-msg`
- to add authors in the author cache located in your home directory at .git-coauthors:
  `git add-coauthor <author initials> <author name> <author email>`
- from next commit initialize your branch with `git mob <author initial> <author initial>`
- to resume committing without a pair type `git solo`

### Hooks which uphold the commit standards
- `local-hooks` folder organizes two customized hooks to honor commit convention
- the said hooks check for proper commit message format
- the author format
- the 50/72 rules for a commit message

## Terraform code organization
- Terraform code is organized inside automation folder
- Terraform State management is done using S3 encrypted bucket and state file is locked using Dynamo DB
   - to initialize terraform use the following :
   `terraform init -backend-config="shared_credentials_file=<cred file path, downloaded from kdbx>" -backend-config="profile=tfadmin"`f
- terraform plan command asks for interactive variables
- `var.cred` = location of credential file
- `var.accountid` = <AWS account, ask your TL>
- `var.tfuser` = <Operator User, ask your TL>
