
## Terraform code organization
- Terraform code is organized inside automation folder
- Terraform State management is done using S3 encrypted bucket and state file is locked using Dynamo DB
   - to initialize terraform use the following :
   `terraform init -backend-config="shared_credentials_file=<cred file path, downloaded from kdbx>" -backend-config="profile=tfadmin"`f
- terraform plan command asks for interactive variables
- `var.cred` = location of credential file
- `var.accountid` = <AWS account, ask your TL>
- `var.tfuser` = <Operator User, ask your TL>
