package com.msk.utils;

/**
 * Class to handle Utility methods.
 */
public class Utility {

   /**
    * Add a delay during the execution.
    * @param milliSeconds duration in milliseconds.
    * @throws InterruptedException when the sleep is interrupted.
    */
   public void sleepFor(long milliSeconds) throws InterruptedException {
        Thread.sleep(milliSeconds);
      }
}
