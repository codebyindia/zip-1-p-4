# terraform

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_kubernetes"></a> [kubernetes](#requirement\_kubernetes) | 2.10.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_aws.origin"></a> [aws.origin](#provider\_aws.origin) | n/a |
| <a name="provider_kubernetes"></a> [kubernetes](#provider\_kubernetes) | 2.10.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [kubernetes_job.msk-integtest](https://registry.terraform.io/providers/hashicorp/kubernetes/2.10.0/docs/resources/job) | resource |
| [kubernetes_namespace.integ_test_namespace](https://registry.terraform.io/providers/hashicorp/kubernetes/2.10.0/docs/resources/namespace) | resource |
| [aws_eks_cluster.cluster](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/eks_cluster) | data source |
| [aws_eks_cluster_auth.cluster](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/eks_cluster_auth) | data source |
| [aws_secretsmanager_secret.destination-msk-secret](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/secretsmanager_secret) | data source |
| [aws_secretsmanager_secret.source-msk-secret](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/secretsmanager_secret) | data source |
| [aws_secretsmanager_secret_version.destination-msk-secret-version](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/secretsmanager_secret_version) | data source |
| [aws_secretsmanager_secret_version.source-msk-secret-version](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/secretsmanager_secret_version) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_account_id"></a> [account\_id](#input\_account\_id) | The ID of the AWS account where Terraform will be run. | `string` | n/a | yes |
| <a name="input_artifactory_path"></a> [artifactory\_path](#input\_artifactory\_path) | n/a | `string` | `"artifactory.blackstone.com/docker-local/devops/thoughtworks"` | no |
| <a name="input_destination-msk-secret-name"></a> [destination-msk-secret-name](#input\_destination-msk-secret-name) | n/a | `string` | n/a | yes |
| <a name="input_eks_cluster_name"></a> [eks\_cluster\_name](#input\_eks\_cluster\_name) | n/a | `string` | n/a | yes |
| <a name="input_eks_splunk_app_name"></a> [eks\_splunk\_app\_name](#input\_eks\_splunk\_app\_name) | n/a | `string` | n/a | yes |
| <a name="input_eks_splunk_index_prefix"></a> [eks\_splunk\_index\_prefix](#input\_eks\_splunk\_index\_prefix) | n/a | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | n/a | `string` | n/a | yes |
| <a name="input_integ_test_bootstrap_server_source"></a> [integ\_test\_bootstrap\_server\_source](#input\_integ\_test\_bootstrap\_server\_source) | n/a | `string` | n/a | yes |
| <a name="input_integ_test_bootstrap_server_target"></a> [integ\_test\_bootstrap\_server\_target](#input\_integ\_test\_bootstrap\_server\_target) | n/a | `string` | n/a | yes |
| <a name="input_integ_test_namespace"></a> [integ\_test\_namespace](#input\_integ\_test\_namespace) | n/a | `string` | n/a | yes |
| <a name="input_is_prod"></a> [is\_prod](#input\_is\_prod) | True if it's prod environment, false if it's nonprod | `bool` | `false` | no |
| <a name="input_kafka_secret_associations"></a> [kafka\_secret\_associations](#input\_kafka\_secret\_associations) | A collection of the MSK secret associations. | <pre>map(object({<br>    cluster                   = string,<br>    username                  = string,<br>    secret_name               = string,<br>    cross_account_access_arns = list(string)<br>  }))</pre> | n/a | yes |
| <a name="input_kinesis_stream_name"></a> [kinesis\_stream\_name](#input\_kinesis\_stream\_name) | # EKS | `string` | n/a | yes |
| <a name="input_msk_broker_ip_us_east_1"></a> [msk\_broker\_ip\_us\_east\_1](#input\_msk\_broker\_ip\_us\_east\_1) | n/a | `list(string)` | n/a | yes |
| <a name="input_primary_region"></a> [primary\_region](#input\_primary\_region) | The Primary region where Terraform will deploy infrastructure. | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | The Secondary region where Terraform will deploy infrastructure. | `string` | n/a | yes |
| <a name="input_sns_topic_arn"></a> [sns\_topic\_arn](#input\_sns\_topic\_arn) | n/a | `string` | `"arn:aws:sns:us-east-1:836156801553:MSK_Cloudwatch_Lambda_Trigger"` | no |
| <a name="input_source-msk-secret-name"></a> [source-msk-secret-name](#input\_source-msk-secret-name) | n/a | `string` | n/a | yes |
| <a name="input_source_image_name"></a> [source\_image\_name](#input\_source\_image\_name) | n/a | `string` | `"msk-dr-integ-test"` | no |
| <a name="input_source_image_tag"></a> [source\_image\_tag](#input\_source\_image\_tag) | n/a | `string` | `"latest"` | no |
| <a name="input_splunk_annotations_env"></a> [splunk\_annotations\_env](#input\_splunk\_annotations\_env) | n/a | `string` | n/a | yes |
| <a name="input_splunk_environment"></a> [splunk\_environment](#input\_splunk\_environment) | n/a | `string` | `"nonprod"` | no |
| <a name="input_splunk_hec_token"></a> [splunk\_hec\_token](#input\_splunk\_hec\_token) | n/a | `string` | n/a | yes |
| <a name="input_vpc_id_us_east_1"></a> [vpc\_id\_us\_east\_1](#input\_vpc\_id\_us\_east\_1) | n/a | `string` | n/a | yes |
| <a name="input_workspace"></a> [workspace](#input\_workspace) | The environmental suffix to append to the workspace name in Terraform Enterprise. | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
