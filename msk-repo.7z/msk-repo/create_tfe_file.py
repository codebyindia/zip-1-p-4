import os
import json
import sys

tfe_token = os.getenv("TFE_TOKEN")
tfe_url = os.getenv("TFE_INSTANCE_URL")
if not tfe_token:
    print ("TFE_TOKEN not set")
    sys.exit(1)

data = {
  "credentials": {
    tfe_url: {
      "token": tfe_token
    },
    "localterraform.com": {
      "token": tfe_token
    },
  }
}
with open(sys.argv[1], 'w') as outfile:
    json.dump(data, outfile)
