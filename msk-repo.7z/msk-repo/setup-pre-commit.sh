#! /usr/bin/env bash
# TODO: Fix repeating steps with parameterized functions
# scan pre-requisite
echo "Checking if brew is installed in your laptop 1/9"
command -v brew
if [ $? -eq 0 ]
then
  echo "Great ! brew available in the laptop (1/9)"
else
  echo "brew is unavailable - installing homebrew"
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  # additional steps for linuxbrew
  uname -s | grep "Linux" 1> /dev/null
  if [ $? -eq 0 ] ; then
    echo "performing extra steps for linux ..."
    test -d ~/.linuxbrew && eval "$(~/.linuxbrew/bin/brew shellenv)"
    test -d /home/linuxbrew/.linuxbrew && eval "$(/home/linuxbrew/.linuxbrew/bin/brew shellenv)"
    test -r ~/.bash_profile && echo "eval \"\$($(brew --prefix)/bin/brew shellenv)\"" >>~/.bash_profile
    echo "eval \"\$($(brew --prefix)/bin/brew shellenv)\"" >>~/.profile
  fi
fi

echo "checking if npm available (2/9)"
test -f /home/linuxbrew/.linuxbrew/bin/npm && test -f /home/linuxbrew/.linuxbrew/bin/node
if [ $? -eq 0 ]
then
  echo "Great ! npm is installed in laptop(2/9)."
else
  echo "npm is not available - installing node"
  brew install node
fi

# installation

command -v pre-commit
if [ $? -eq 1 ]
then
  echo "pre-commit is being installed in laptop (3/9)..."
  brew install pre-commit
  if [ $? -eq 1 ]
  then
    echo "pre-commit installation failed (3/9)..."
    exit 1
    fi
else
  echo "pre-commit already installed (3/9)"
fi

if [ -f .git/hooks/pre-commit ]
then
  echo "pre-commit hook already installed ...(4/9)"
else
  echo "enabling pre-commit in your current repository (4/9)"
  pre-commit install
  if [ $? -eq 0 ]
  then
    echo "pre-commit hook is installed in current repository.(4/9)"
  else
    echo "pre-commit hooks could not be installed for the current repo(4/9)."
    exit 1
  fi
fi

npm list -g git-mob
if [ $? -eq 1 ]
then
  echo "installing git-mob (5/9)."
  CERT_FILEPATH="/usr/local/share/ca-certificates/ZscalerRootCertificate-2048-SHA256.crt"
  if [ -f $CERT_FILEPATH ] ; then
    export NODE_EXTRA_CA_CERTS=$CERT_FILEPATH
    npm install -g git-mob
    if [ $? -eq 1 ]
    then
      echo "git-mob installation failed (5/9)."
      exit 1
    fi
  else
    echo "Was expecting the following file: /usr/local/share/ca-certificates/ZscalerRootCertificate-2048-SHA256.crt"
  fi
else
  echo "git-mob already installed (5/9)"
fi

if [ -f .git/hooks/prepare-commit-msg ]
then
  echo "pre-commit-msg hook already installed ...(6/9)"
else
  echo "enabling pre-commit-msg hook stage in your current repository (6/9)"
  pre-commit install --hook-type prepare-commit-msg
  if [ $? -eq 0 ]
  then
    echo "pre-commit is installed in laptop(6/9)."
  else
    echo "pre-commit hooks could not be installed for the current repo(6/9)."
    exit 1
  fi
fi


command -v terraform-docs
if [ $? -eq 1 ]
then
  echo "terraform-docs is being installed in laptop (7/9)..."
  brew install {terraform,terraform-docs}
  if [ $? -eq 1 ]
  then
    echo "terraform-docs installation failed (7/9)..."
    exit 1
    fi
else
  echo "terraform-docs already installed(7/9)"
fi

command -v talisman
if [ $? -eq 1 ]
then
  echo "talisman is being installed in laptop (8/9)..."
  brew install {go,talisman}
  if [ $? -eq 1 ]
  then
    echo "talisman installation failed (8/9)..."
    exit 1
    fi
else
  echo "talisman already installed(8/9)"
fi

command -v tfsec
if [ $? -eq 1 ]
then
  echo "tfsec is being installed in laptop (9/9)..."
  brew install tfsec
  if [ $? -eq 1 ]
  then
    echo "tfsec installation failed (8/9)..."
    exit 1
    fi
else
  echo "tfsec already installed(9/9)"
fi
