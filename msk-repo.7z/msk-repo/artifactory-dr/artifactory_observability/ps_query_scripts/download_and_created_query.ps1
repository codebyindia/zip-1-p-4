$folderName = ".\sprint_8\authored\downEqTo3\last2mo"


$before = '18mo'
$last = '24mo'

$json_query = @"
items.find(
{
    "stat.downloads":{"`$eq":3}
},
{
    "created_by":{"`$nmatch":"*anonymous*"}
},
{
    "stat.downloaded": {"`$last": "2mo"}
},
{
    "`$and":
    [
        {"created":{"`$before" : "$before"}},
        {"created":{"`$last" : "$last"}}
    ]
}
).include("name","path","size", "created_by", "stat.downloaded_by", "stat.downloaded")
"@

$json_query | Out-File -Encoding "Ascii" -FilePath ".\common_query.json"
# $raw_query = ConvertFrom-Json $json_query
jf rt curl -X POST /api/search/aql -T common_query.json | Out-File -FilePath .\${folderName}\created_between_${before}_And_${last}_ago.json
