"""
This module contains the functions that process the outpuut of a query with regards to paths and sizes.

The main function of this modeule is path_and_size_pipeline. It expects:

    arguments:
    ________________
    folder_path: str -- path to the folder where the query results are;
    skip_files: list -- a list of files to be skipped from processing;


    return:
    ________________
    nothing, it writes the results in json files on the path: folder_path + results
"""

import json
import os
import re
from utilities import (
    get_printable_size,
    select_files,
    order_dict_by_key,
    turn_None_into_0,
    get_root,
)
from utilities import (
    write_result_to_file,
    create_root_folder,
    build_folder_dict,
    readable_size,
    order_dict_by_value,
)
from rich import print


###
### Processing data
###
def get_total_size_of_query(folder_path, skip_files, identifier):
    """
    arguments:
    ________________
    folder_path: str -- path to the folder where the query results are;
    skip_files: list -- a list of files to be skipped from processing;
    identifier: str -- a unique pattern to look for in the filename, ex: last(.+?)mo

    Calculates the size of each file ina set of query files.

    return:
    ________________
    query_size: dict -- a dict where {key=identifier : value=size}
    """
    period_usage_dict = {}
    query_files = os.listdir(folder_path)

    selected_query_files = select_files(query_files, skip_files)

    print("selected files in path: ", query_files)
    print("all files in the path: ", selected_query_files)

    for file in selected_query_files:
        file_size_sum = 0
        key = re.search(identifier, file).group(1)
        file_path = folder_path + file
        with open(file_path, "rb") as opened_file:
            data = opened_file.read()
            json_data = json.loads(data)
            for result_dict in json_data["results"]:
                size = result_dict.get("size")
                file_size_sum += size

            period_usage_dict[key] = get_printable_size(file_size_sum)

    return period_usage_dict


def get_unique_folders(folder_path, skip_files):
    """
    arguments:
    ________________
    folder_path: str -- path to the folder where the query results are;
    skip_files: list -- a list of files to be skipped from processing;

    returns:
    ________________
    unique_folders_paths: list -- all the unique folders in the query;
    """
    query_files = os.listdir(folder_path)

    selected_query_files = select_files(query_files, skip_files)
    unique_folders_paths = []
    unique_root_paths = []
    for file in selected_query_files:

        file_path = folder_path + file
        with open(file_path, "rb") as opened_file:
            data = opened_file.read()
            json_data = json.loads(data)
            for result_dict in json_data["results"]:
                folder_list = result_dict.get("path").split("/")
                # print(result_dict.get("path"))
                unique_folder_path = create_root_folder(folder_list)
                unique_root = get_root(folder_list)
                if unique_folder_path not in unique_folders_paths:
                    unique_folders_paths.append(unique_folder_path)
                if unique_root not in unique_root_paths:
                    unique_root_paths.append(unique_root)

    return unique_root_paths #unique_folders_paths


def get_folder_size_over_time(folder_path, skip_files, identifier, folder_list):
    """
    arguments:
    ________________
    folder_path: str -- path to the folder where the query results are;
    skip_files: list -- a list of files to be skipped from processing;
    identifier: str -- a unique pattern to look for in the filename, ex: last(.+?)mo
    folder_list: list -- contains all the unique paths in the queries;

    Calculates the size of each folder over all the results in the query.

    returns:
    ________________
    nothing, it writes directly to the filesystem.
    Dictionaries created with this function are used for calculating the space occupied by each path.
    """
    query_files = os.listdir(folder_path)

    selected_query_files = select_files(query_files, skip_files)

    for file in selected_query_files:
        unique_folders = {}
        file_path = folder_path + file
        period = re.search(identifier, file).group(1)
        unique_folders = build_folder_dict(folder_list)
        with open(file_path, "rb") as opened_file:
            data = opened_file.read()
            json_data = json.loads(data)
            for result_dict in json_data["results"]:
                current_path = result_dict.get("path")
                size = result_dict.get("size")
                for folder in unique_folders.keys():
                    if current_path.startswith(folder):
                        if unique_folders[folder] is None:
                            unique_folders[folder] = size
                        else:
                            unique_folders[folder] += size

            write_result_to_file(folder_path, "raw_size_" + period, unique_folders)
            # write_result_to_file(folder_path, period, readable_size(unique_folders))


def get_largest_paths(folder_path):
    """
    arguments:
    ________________
    folder_path: str -- path to the folder where the query results are;

    Calculates the largest path in a given query file.

    returns:
    ________________
    nothing, it writes directly to the filesystem in the following format; ex:largest_path_in_the_last_18mo

    """
    results_path = folder_path + "results/"
    result_files = os.listdir(results_path)
    for fl in result_files:
        if "raw_size_" not in fl:
            continue
        file_path = results_path + fl
        period = re.search("raw_size_(.+?).json", fl).group(1)
        with open(file_path, "rb") as opened_file:
            data = opened_file.read()
            json_data = json.loads(data)
            currated_dict = turn_None_into_0(json_data)
            largest_paths = order_dict_by_value(currated_dict)
            write_result_to_file(
                folder_path, period + "_months", readable_size(largest_paths)
            )


def path_and_size_pipeline(folder_path, skip_files):

    # folder_path = "../sprint_8/docker_local/downloaded_eqTo1/"
    # skip_files = ["common_query.json", "results"]

    total_size_of_query = get_total_size_of_query(
        folder_path, skip_files, "between_(.+?)_ago"
    )
    write_result_to_file(folder_path, "size_between", total_size_of_query)
    unique_folders = get_unique_folders(folder_path, skip_files)
    write_result_to_file(folder_path, "unique_paths", unique_folders)
    get_folder_size_over_time(
        folder_path, skip_files, "between_(.+?)_ago", unique_folders
    )
    get_largest_paths(folder_path)
