# MSK DR Tests
## _Test package to funtionaly evaluate MSK DR Implementation_

[![N|Solid](https://user-images.githubusercontent.com/12598420/86005149-287ee480-ba0c-11ea-91a0-d0811f15be75.png)](https://github.com/authorjapps/zerocode)

[![Build Status](https://gitlab.blackstone.com/devops/msk-repo/badges/msk-dr/pipeline.svg)](https://gitlab.blackstone.com/devops/msk-repo/-/tree/msk-dr)

# About

This is the Integration test package for evaluating the MSK DR Implementation.

[Test Strategy](https://blackstone.jira.com/wiki/spaces/PLATIN/pages/3004498253/Test+Strategy+to+evaluate+MM2+based+DR+solution)

[Test Cases](https://blackstone.jira.com/wiki/spaces/PLATIN/pages/3041034975/Testcase+and+Execution+Flow)

[Test Automation](https://blackstone.jira.com/wiki/spaces/PLATIN/pages/3024750457/Test+Automation)

# Execution

 Gradle is used to build the package. Tests can be executed using 'java'.

```
Build:
./gradlew -d jar

Execute:
java -cp <build/libs/target.jar> <target_class>
```

# Dockerising the test

To dockerize the test code, we are caching the dependencies and execute the test offline. This avoids downloading dependencies for every run.

```
./gradlew -d jar
docker build -t <ARTIFACT PATH>/<ARTIFACT NAME>:<IMAGE VERSION>
```

While executing from pipline, the `makefile` will be used in-place of the above commands.

```
To build the image locally:
    make

To push the image into artifactory
    make artifactory-login
    make publish-image
```
