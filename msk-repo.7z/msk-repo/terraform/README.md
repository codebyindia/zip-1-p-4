# terraform

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | ~> 3.74 |
| <a name="requirement_helm"></a> [helm](#requirement\_helm) | 2.5.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_archive"></a> [archive](#provider\_archive) | n/a |
| <a name="provider_aws"></a> [aws](#provider\_aws) | ~> 3.74 |
| <a name="provider_aws.origin"></a> [aws.origin](#provider\_aws.origin) | ~> 3.74 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_bx_msk_cluster"></a> [bx\_msk\_cluster](#module\_bx\_msk\_cluster) | localterraform.com/blackstone/bx_msk_cluster/aws | 2.0.5 |
| <a name="module_eks_msk_dr"></a> [eks\_msk\_dr](#module\_eks\_msk\_dr) | localterraform.com/blackstone/bx_private_eks/aws | 3.0.7 |
| <a name="module_fluent_bit"></a> [fluent\_bit](#module\_fluent\_bit) | localterraform.com/blackstone/bx_fluentbit_helm_release/aws | 3.2.4 |
| <a name="module_kafka_proxy_role"></a> [kafka\_proxy\_role](#module\_kafka\_proxy\_role) | localterraform.com/blackstone/bx_iam_role/aws | v0.1.4 |
| <a name="module_kinesis"></a> [kinesis](#module\_kinesis) | localterraform.com/blackstone/fluent_bit_kinesis_stream_splunk/aws | 0.15.0 |
| <a name="module_lambda_role"></a> [lambda\_role](#module\_lambda\_role) | localterraform.com/blackstone/bx_iam_role/aws | v0.1.4 |
| <a name="module_sasl_scram_secret"></a> [sasl\_scram\_secret](#module\_sasl\_scram\_secret) | localterraform.com/blackstone/bx_msk_sasl_scram_secret/aws | 0.3.3 |
| <a name="module_source_cidr_blocks"></a> [source\_cidr\_blocks](#module\_source\_cidr\_blocks) | localterraform.com/blackstone/bx_standard_ingress_cidrs/aws | 0.6.0 |

## Resources

| Name | Type |
|------|------|
| [aws_iam_instance_profile.bx_kafka_proxy_profile](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_instance_profile) | resource |
| [aws_iam_policy.disable_failback_lambda_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_iam_role_policy_attachment.disable_failback_policy_attach](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_iam_role_policy_attachment.kafka_proxy_role_attachment](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_instance.kafka-proxy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/instance) | resource |
| [aws_kms_grant.msk_ops_kms_grant](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/kms_grant) | resource |
| [aws_lambda_function.disable_failback](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_function) | resource |
| [aws_lambda_permission.allow_SNS_trigger](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_permission) | resource |
| [aws_lambda_permission.allow_SNS_trigger_lambda](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_permission) | resource |
| [aws_lb.msk_nlb](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb) | resource |
| [aws_lb.msk_nlb_us_east_1](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb) | resource |
| [aws_lb_listener.msk_nlb](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_listener) | resource |
| [aws_lb_target_group.msk_nlb_tg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group) | resource |
| [aws_lb_target_group.msk_nlb_tg_us_east_1](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group) | resource |
| [aws_lb_target_group.msk_nlb_unhealthy_tg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group) | resource |
| [aws_lb_target_group_attachment.msk_nlb_tg_attach_us_east_1](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group_attachment) | resource |
| [aws_lb_target_group_attachment.msk_nlb_unhealthy_tg_attachment](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group_attachment) | resource |
| [aws_lb_target_group_attachment.test](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lb_target_group_attachment) | resource |
| [aws_msk_configuration.config](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/msk_configuration) | resource |
| [aws_msk_scram_secret_association.secret_association](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/msk_scram_secret_association) | resource |
| [aws_route53_record.primary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_route53_record.secondary](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route53_record) | resource |
| [aws_security_group.kafka-proxy-security-group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_security_group.msk_security_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_sns_topic.msk_cloudwatch_lambda_trigger](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sns_topic) | resource |
| [aws_sns_topic_subscription.lambda_trigger_subscription](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sns_topic_subscription) | resource |
| [aws_sns_topic_subscription.sns_lambda_trigger_subscription](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sns_topic_subscription) | resource |
| [random_uuid.lambda_source_hash](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/uuid) | resource |
| [archive_file.lambda_source_code](https://registry.terraform.io/providers/hashicorp/archive/latest/docs/data-sources/file) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_eks_cluster.eks](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/eks_cluster) | data source |
| [aws_eks_cluster_auth.eks](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/eks_cluster_auth) | data source |
| [aws_iam_policy_document.lambda_assume_role_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.trust](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_lambda_function.lambda](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/lambda_function) | data source |
| [aws_secretsmanager_secret.source-msk-secret-test](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/secretsmanager_secret) | data source |
| [aws_secretsmanager_secret_version.source-msk-secret-version-test](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/secretsmanager_secret_version) | data source |
| [aws_security_groups.msk_sg](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/security_groups) | data source |
| [aws_subnet_ids.subnets](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnet_ids) | data source |
| [aws_subnet_ids.subnets_us_east_1](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnet_ids) | data source |
| [aws_vpc.selected](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/vpc) | data source |
| [aws_vpc.vpc](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/vpc) | data source |
| [aws_vpc.vpc_us_east_1](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/vpc) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_account_id"></a> [account\_id](#input\_account\_id) | The ID of the AWS account where Terraform will be run. | `string` | n/a | yes |
| <a name="input_bx_eks_admin_role_arn"></a> [bx\_eks\_admin\_role\_arn](#input\_bx\_eks\_admin\_role\_arn) | The ARN for the operator role that needs access to the KMS key to retrieve secrets | `string` | n/a | yes |
| <a name="input_default_kafka_versions"></a> [default\_kafka\_versions](#input\_default\_kafka\_versions) | The default supported kafka versions for the default configuration | `list(string)` | <pre>[<br>  "2.2.1",<br>  "2.3.1",<br>  "2.4.1.1",<br>  "2.5.1",<br>  "2.6.0"<br>]</pre> | no |
| <a name="input_eks_cluster_name"></a> [eks\_cluster\_name](#input\_eks\_cluster\_name) | n/a | `string` | n/a | yes |
| <a name="input_eks_desired_capacity"></a> [eks\_desired\_capacity](#input\_eks\_desired\_capacity) | n/a | `number` | n/a | yes |
| <a name="input_eks_instance_type"></a> [eks\_instance\_type](#input\_eks\_instance\_type) | n/a | `string` | n/a | yes |
| <a name="input_eks_max_capacity"></a> [eks\_max\_capacity](#input\_eks\_max\_capacity) | n/a | `number` | n/a | yes |
| <a name="input_eks_min_capacity"></a> [eks\_min\_capacity](#input\_eks\_min\_capacity) | n/a | `number` | n/a | yes |
| <a name="input_eks_splunk_app_name"></a> [eks\_splunk\_app\_name](#input\_eks\_splunk\_app\_name) | n/a | `string` | n/a | yes |
| <a name="input_eks_splunk_index_prefix"></a> [eks\_splunk\_index\_prefix](#input\_eks\_splunk\_index\_prefix) | n/a | `string` | n/a | yes |
| <a name="input_environment"></a> [environment](#input\_environment) | n/a | `string` | n/a | yes |
| <a name="input_is_prod"></a> [is\_prod](#input\_is\_prod) | True if it's prod environment, false if it's nonprod | `bool` | `false` | no |
| <a name="input_kafka_instances"></a> [kafka\_instances](#input\_kafka\_instances) | The environment specific instances since there's more than one per workspace | <pre>map(object({<br>    broker_instance_type              = string,<br>    kafka_version                     = string,<br>    super_users                       = string,<br>    num_kafka_broker_nodes            = number,<br>    cidr_blocks                       = list(string)<br>    include_onprem_cidrs              = bool<br>    include_aws_cidrs                 = bool<br>    include_shared_services_aws_cidrs = bool<br>  }))</pre> | n/a | yes |
| <a name="input_kinesis_stream_name"></a> [kinesis\_stream\_name](#input\_kinesis\_stream\_name) | # EKS | `string` | n/a | yes |
| <a name="input_lambda_healthy_values"></a> [lambda\_healthy\_values](#input\_lambda\_healthy\_values) | n/a | `string` | `"healthy,initial"` | no |
| <a name="input_lambda_region"></a> [lambda\_region](#input\_lambda\_region) | n/a | `string` | `"us-east-1,us-east-2"` | no |
| <a name="input_msk_broker_ip"></a> [msk\_broker\_ip](#input\_msk\_broker\_ip) | n/a | `list(string)` | n/a | yes |
| <a name="input_msk_broker_ip_us_east_1"></a> [msk\_broker\_ip\_us\_east\_1](#input\_msk\_broker\_ip\_us\_east\_1) | n/a | `list(string)` | n/a | yes |
| <a name="input_primary_nlb_name"></a> [primary\_nlb\_name](#input\_primary\_nlb\_name) | n/a | `string` | `"primary-msk-nlb"` | no |
| <a name="input_primary_tg_name"></a> [primary\_tg\_name](#input\_primary\_tg\_name) | n/a | `string` | `"primary-msk-tg"` | no |
| <a name="input_region"></a> [region](#input\_region) | The region where Terraform will deploy infrastructure. | `string` | n/a | yes |
| <a name="input_secondary_nlb_name"></a> [secondary\_nlb\_name](#input\_secondary\_nlb\_name) | n/a | `string` | `"secondary-msk-nlb"` | no |
| <a name="input_secondary_tg_name"></a> [secondary\_tg\_name](#input\_secondary\_tg\_name) | n/a | `string` | `"secondary-msk-tg"` | no |
| <a name="input_sns_topic_arn"></a> [sns\_topic\_arn](#input\_sns\_topic\_arn) | n/a | `string` | `"arn:aws:sns:us-east-1:836156801553:MSK_Cloudwatch_Lambda_Trigger"` | no |
| <a name="input_source_msk_secrets"></a> [source\_msk\_secrets](#input\_source\_msk\_secrets) | n/a | <pre>map(object({<br>    cluster                   = string,<br>    secret_name               = string,<br>    cross_account_access_arns = list(string)<br>  }))</pre> | n/a | yes |
| <a name="input_splunk_environment"></a> [splunk\_environment](#input\_splunk\_environment) | # Docker Image | `string` | `"nonprod"` | no |
| <a name="input_splunk_hec_token"></a> [splunk\_hec\_token](#input\_splunk\_hec\_token) | n/a | `string` | n/a | yes |
| <a name="input_unhealthy_tg_name"></a> [unhealthy\_tg\_name](#input\_unhealthy\_tg\_name) | n/a | `string` | `"primary-msk-unhealthy-tg"` | no |
| <a name="input_us_east_1_subnet_filter"></a> [us\_east\_1\_subnet\_filter](#input\_us\_east\_1\_subnet\_filter) | n/a | `string` | n/a | yes |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | The ID of the VPC where Terraform will deploy infrastructure. | `string` | n/a | yes |
| <a name="input_vpc_id_us_east_1"></a> [vpc\_id\_us\_east\_1](#input\_vpc\_id\_us\_east\_1) | n/a | `string` | n/a | yes |
| <a name="input_workspace"></a> [workspace](#input\_workspace) | The environmental suffix to append to the workspace name in Terraform Enterprise. | `string` | n/a | yes |
| <a name="input_zone_id"></a> [zone\_id](#input\_zone\_id) | n/a | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
