#!/usr/bin/env bash -e
curl -sSfL https://raw.githubusercontent.com/anchore/grype/main/install.sh | sh -s -- -b /usr/local/bin
grype $1 --scope AllLayers --fail-on=critical --config $WORKSPACE/$makefile_dir/.grype.yaml
