#!/usr/bin/env bash -e
command -v uname
if [ $? = 0 ]; then
    capture=$(uname -m)
    echo "capture: $capture"
    version=$2
    exit_on=$3
    if [ $capture = 'x86_64' ]; then
        arch=64bit
    elif [ $capture = 'i386' -o $capture = 'i686'  ]; then
        arch=32bit
    else
        echo "Unkown/unsupported build agent architecture"
        exit 1
    fi
    binaryPrefix=dockle_$version
    binarySuffix=_Linux-$arch.tar.gz
    binary="$binaryPrefix$binarySuffix"
    echo "dockle binary : $binary"
    url="https://github.com/goodwithtech/dockle/releases/download/v$version/$binary"
    echo "getting from : $url"
    wget -nc $url
    tar -xvf $binary
    ./dockle -q $1 > dockle.out
    grep $exit_on dockle.out
    if [ $? = 0 ]; then
        cat dockle.out
        exit 1
    else
        cat dockle.out
        exit 0
    fi
fi
