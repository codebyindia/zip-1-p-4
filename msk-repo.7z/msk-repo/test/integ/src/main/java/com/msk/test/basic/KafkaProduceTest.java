package com.msk.test.basic;

import com.msk.MSKDRKafkaClient;

import org.jsmart.zerocode.core.domain.Scenario;
import org.jsmart.zerocode.core.domain.TargetEnv;
import org.jsmart.zerocode.core.domain.UseKafkaClient;
import org.jsmart.zerocode.core.runner.ZeroCodeUnitRunner;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@TargetEnv("config/msk_broker.properties")
@RunWith(ZeroCodeUnitRunner.class)
@UseKafkaClient(MSKDRKafkaClient.class)
public class KafkaProduceTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaProduceTest.class);

    @Test
    public void testCredentialAccess() {
        LOGGER.info("User name: " + System.getenv("SOURCE_MSK_USER_NAME"));
        LOGGER.info("Is password empty?: " + System.getenv("SOURCE_MSK_PASSWORD").isEmpty());
    }

    @Test
    @Scenario("scenarios/test_kafka_consume.json")
    public void testProduceAndConsume() {
    }

    @Test
    @Scenario("scenarios/test_message_idemptency.json")
    public void testMessageIdempotency() {
    }

    @Test
    @Scenario("scenarios/test_offset.json")
    public void testOffsetScenario() {
    }

    @Test
    @Scenario("scenarios/test_message_read.json")
    public void testOffsetBasedMessageRead() {
    }
}
